﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace CRUDApi.Models
{
    public class CRUDAppContext : DbContext
    {
        public CRUDAppContext (DbContextOptions<CRUDAppContext> options)
            : base(options)
        {
        }

        public DbSet<Employee> Employee { get; set; }
    }
}
