﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRUDApi.Models
{
	public class Employee
	{
		[Key]
		public int EmpId { get; set; }
		[Column(TypeName = "nvarchar(50)")]
		[Required(ErrorMessage = "Name is required")]
		public string Name { get; set; }
		[Required(ErrorMessage = "Mobile No is required")]
		[Display(Name = "Mobile No")]
		public string MobileNo { get; set; }
		[Required(ErrorMessage = "Address is required")]
		[StringLength(1000)]
		public string Address { get; set; }
		[Required]
		[DataType(DataType.EmailAddress, ErrorMessage = "E-mail is not valid")]
		public string Email { get; set; }
	}
}
